package LvL;

import java.util.ArrayList;

public class Cinema {

	ArrayList <Cinema> sala=new ArrayList ();
	
	ArrayList<Cinema> sessao=new ArrayList<>();
	
	boolean pol [][]=new boolean [15][10];
	
	pol=pol
}
